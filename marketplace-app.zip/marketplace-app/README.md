# 🚀 Ma Marketplace - Application de Petites Annonces

Application web progressive (PWA) de marketplace spécialisé, construite avec React et Firebase.

## 📦 Installation

### Prérequis
- Node.js (version 18 ou supérieure)
- npm ou yarn

### Étapes

1. **Installer les dépendances**
```bash
npm install
```

2. **Lancer en mode développement**
```bash
npm run dev
```

L'application sera accessible sur `http://localhost:5173`

3. **Builder pour la production**
```bash
npm run build
```

## 🚀 Déploiement sur Vercel

### Méthode 1 : Via le terminal (la plus rapide)

1. **Installer Vercel CLI**
```bash
npm install -g vercel
```

2. **Déployer**
```bash
vercel
```

Suivez les instructions, et votre app sera en ligne en 30 secondes !

### Méthode 2 : Via GitHub + Interface Vercel

1. **Créer un repo GitHub et pusher le code**
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin VOTRE_REPO_URL
git push -u origin main
```

2. **Aller sur vercel.com**
   - Se connecter avec GitHub
   - Import Project
   - Sélectionner votre repo
   - Deploy

Vercel détecte automatiquement Vite et configure tout !

## 📱 Test sur mobile

1. **Trouver votre IP locale**
```bash
# Sur Mac/Linux
ifconfig | grep inet

# Sur Windows
ipconfig
```

2. **Accéder depuis votre téléphone**
```
http://VOTRE_IP:5173
```

Exemple : `http://192.168.1.10:5173`

## 🎯 Prochaines étapes

- [ ] Ajouter Firebase Authentication
- [ ] Créer la liste des annonces
- [ ] Formulaire de publication
- [ ] Profil utilisateur
- [ ] Messagerie entre utilisateurs
- [ ] Upload de photos
- [ ] Filtres et recherche

## 🛠 Technologies utilisées

- **React** - Framework UI
- **Vite** - Build tool ultra-rapide
- **Firebase** (à venir) - Backend as a Service
  - Authentication
  - Firestore (base de données)
  - Storage (photos)

## 📚 Structure du projet

```
marketplace-app/
├── public/
│   └── manifest.json     # Configuration PWA
├── src/
│   ├── App.jsx          # Composant principal
│   ├── App.css          # Styles
│   └── main.jsx         # Point d'entrée
├── index.html           # HTML de base
├── package.json         # Dépendances
└── vite.config.js       # Configuration Vite
```

## 💡 Conseils

- **Pendant le développement** : Utilisez `npm run dev` pour voir les changements en temps réel
- **Pour tester sur mobile** : Assurez-vous d'être sur le même WiFi
- **Pour déployer** : `vercel` depuis le dossier du projet

## 🆘 Problèmes courants

**Port déjà utilisé ?**
```bash
# Vite utilisera automatiquement le port suivant (5174, 5175, etc.)
```

**npm install échoue ?**
```bash
# Essayez de vider le cache
npm cache clean --force
npm install
```

---

Créé avec ❤️ pour ta marketplace
