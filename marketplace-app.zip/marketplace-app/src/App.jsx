import { useState } from 'react'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div className="app">
      <div className="container">
        <h1>🚀 Hello World - Ma Marketplace</h1>
        <p className="subtitle">
          Bienvenue dans votre application de petites annonces !
        </p>
        
        <div className="card">
          <h2>Compteur de test</h2>
          <button onClick={() => setCount(count + 1)}>
            Clics : {count}
          </button>
          <p className="info">
            Cliquez sur le bouton pour tester l'interactivité React
          </p>
        </div>

        <div className="features">
          <h3>✨ Prochaines étapes :</h3>
          <ul>
            <li>🔐 Authentification Firebase</li>
            <li>📋 Liste des annonces</li>
            <li>➕ Formulaire de publication</li>
            <li>👤 Profil utilisateur</li>
            <li>💬 Messagerie</li>
          </ul>
        </div>

        <footer className="footer">
          <p>Prêt à construire ton app ! 💪</p>
        </footer>
      </div>
    </div>
  )
}

export default App
